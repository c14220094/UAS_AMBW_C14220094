class Constants {
  static const String supabaseUrl = 'https://mzfmrtuwattxmwqkodan.supabase.co';
  static const String supabaseAnonKey =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im16Zm1ydHV3YXR0eG13cWtvZGFuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA4OTYxMjQsImV4cCI6MjA2NjQ3MjEyNH0.CE9zL_2yR1XfHHJMN-bul8vf7WM-6J9Z5rHGlF48eDg';

  static const String keyFirstTime = 'first_time';
  static const String keyIsLoggedIn = 'is_logged_in';
  static const String keyUserEmail = 'user_email';
}
