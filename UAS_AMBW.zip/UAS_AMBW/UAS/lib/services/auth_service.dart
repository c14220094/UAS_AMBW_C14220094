import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'storage_service.dart';

class AuthService extends ChangeNotifier {
  final SupabaseClient _supabase = Supabase.instance.client;
  User? _user;

  User? get user => _user;
  bool get isAuthenticated => _user != null;

  AuthService() {
    _user = _supabase.auth.currentUser;
  }

  Future<String?> signUp(String email, String password) async {
    try {
      final response = await _supabase.auth.signUp(
        email: email,
        password: password,
      );

      final user = response.user;
      if (user != null) {
        _user = user;
        StorageService.isLoggedIn = true;
        StorageService.userEmail = email;
        notifyListeners();
        return null;
      } else {
        return 'Sign up gagal. Silakan coba lagi.';
      }
    } on AuthException catch (e) {
      return e.message;
    } catch (e) {
      return 'Terjadi kesalahan saat sign up.';
    }
  }

  Future<String?> signIn(String email, String password) async {
    try {
      final response = await _supabase.auth.signInWithPassword(
        email: email,
        password: password,
      );

      final user = response.user;
      if (user != null) {
        _user = user;
        StorageService.isLoggedIn = true;
        StorageService.userEmail = email;
        notifyListeners();
        return null;
      } else {
        return 'Login gagal. Email atau password salah.';
      }
    } on AuthException catch (e) {
      if (e.message.toLowerCase().contains('email not confirmed')) {
        return 'Email belum dikonfirmasi. Silakan cek inbox kamu.';
      }
      return e.message;
    } catch (e) {
      return 'Terjadi kesalahan saat login.';
    }
  }

  Future<void> signOut() async {
    await _supabase.auth.signOut();
    _user = null;
    await StorageService.clearAll();
    notifyListeners();
  }
}
