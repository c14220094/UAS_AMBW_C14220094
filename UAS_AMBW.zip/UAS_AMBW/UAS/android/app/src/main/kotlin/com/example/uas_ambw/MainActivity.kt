package com.example.uas_ambw

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
