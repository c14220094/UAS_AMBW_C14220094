# Penyimpanan menu secara simple

Aplikasi Flutter untuk menyimpan dan mengatur resep masakan pribadi dengan autentikaasi dan penyimpanan cloud.

## Fitur Utama

- Autentikasi Login
Pengguna dapat melakukan registrasi, masuk, dan keluar menggunakan layanan Supabase Auth.

- Database Online (Cloud)
Semua data resep disimpan di cloud melalui Supabase agar bisa diakses dari mana saja.

- Penyimpanan Status Login (Session Persistence)
Menyimpan status login secara lokal menggunakan SharedPreferences agar pengguna tetap masuk tanpa harus login ulang setiap kali membuka aplikasi.

- Tampilan Get Started
Layar pembuka yang hanya akan muncul saat aplikasi pertama kali diinstal dan dijalankan.

- CRUD Resep
Tambah resep baru, lihat daftar resep, dan hapus resep yang tidak diperlukan.

- Keamanan Data Pengguna
Setiap pengguna hanya dapat melihat dan mengelola resep miliknya sendiri, berkat penggunaan kebijakan keamanan baris (RLS).

## Teknologi yang Digunakan

- Flutter : Framework UI modern untuk membangun aplikasi multiplatform.

- Supabase : Backend sebagai layanan untuk otentikasi dan database.

- Provider : Pengelolaan state aplikasi.

- SharedPreferences : Penyimpanan data lokal untuk menyimpan sesi login pengguna.

## Langkah Install dan Build

### Prerequisites

- Flutter SDK versi 3.10.0 atau lebih baru

- Dart SDK versi 3.0.0 atau lebih baru

- Visual Studio Code atau editor lainnya

- Akun Supabase aktif

### Setup Database

Buat project baru di Supabase.

Masuk ke SQL Editor, lalu jalankan skrip berikut:
```sql
CREATE TABLE recipes (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  ingredients TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);


ALTER TABLE recipes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can only access their own recipes" ON recipes
  FOR ALL USING (auth.uid() = user_id);
```

### Setup Project

Clone repository ini:

```bash
git https://github.com/c14220094/Uas_Ambw_c14220094.git
cd  Uas_Ambw_c14220094
```

Instal dependencies:
```bash
flutter pub get
```

Update file `lib/utils/constants.dart` dengan kredensial Supabase anda:
```dart
class Constants {
  static const String supabaseUrl = 'YOUR_SUPABASE_URL';
  static const String supabaseAnonKey = 'YOUR_SUPABASE_ANON_KEY';
}
```

## Kredensial Testing

Untuk testing, anda bisa membuat akun baru dengan register atau menggunakan kredensial berikut:
- Email: `admin@admin.com`
- Password: `admin123`
